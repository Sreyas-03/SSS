java -jar checkstyle-9.3-all.jar -c checkstyle.xml -f xml -o reader-web.xml ./reader-web
java -jar checkstyle-9.3-all.jar -c checkstyle.xml -f xml -o reader-web-common.xml ./reader-web-common/
java -jar checkstyle-9.3-all.jar -c checkstyle.xml -f xml -o reader-core.xml ./reader-core/

pmd check -R pmd.xml -d ./reader-web -f text --report-file reader-web.txt
pmd check -R pmd.xml -d ./reader-web-common -f text --report-file reader-web-common.txt
pmd check -R pmd.xml -d ./reader-core -f text --report-file reader-core.txt




Prev Directory:

java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_BooleanExpressionComplexity.xml -f xml -o CheckStyle/reader-web_BooleanExpressionComplexity.xml ../reader-web
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_ClassDataAbstractionCoupling.xml -f xml -o CheckStyle/reader-web_ClassDataAbstractionCoupling.xml ../reader-web
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_ClassFanOutComplexity.xml -f xml -o CheckStyle/reader-web_ClassFanOutComplexity.xml ../reader-web
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_CyclomaticComplexity.xml -f xml -o CheckStyle/reader-web_CyclomaticComplexity.xml ../reader-web
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_JavaNCSS.xml -f xml -o CheckStyle/reader-web_JavaNCSS.xml ../reader-web
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_NPathComplexity.xml -f xml -o CheckStyle/reader-web_NPathComplexity.xml ../reader-web

java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_BooleanExpressionComplexity.xml -f xml -o CheckStyle/reader-web-common_BooleanExpressionComplexity.xml ../reader-web-common
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_ClassDataAbstractionCoupling.xml -f xml -o CheckStyle/reader-web-common_ClassDataAbstractionCoupling.xml ../reader-web-common
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_ClassFanOutComplexity.xml -f xml -o CheckStyle/reader-web-common_ClassFanOutComplexity.xml ../reader-web-common
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_CyclomaticComplexity.xml -f xml -o CheckStyle/reader-web-common_CyclomaticComplexity.xml ../reader-web-common
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_JavaNCSS.xml -f xml -o CheckStyle/reader-web-common_JavaNCSS.xml ../reader-web-common
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_NPathComplexity.xml -f xml -o CheckStyle/reader-web-common_NPathComplexity.xml ../reader-web-common

java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_BooleanExpressionComplexity.xml -f xml -o CheckStyle/reader-core_BooleanExpressionComplexity.xml ../reader-core
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_ClassDataAbstractionCoupling.xml -f xml -o CheckStyle/reader-core_ClassDataAbstractionCoupling.xml ../reader-core
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_ClassFanOutComplexity.xml -f xml -o CheckStyle/reader-core_ClassFanOutComplexity.xml ../reader-core
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_CyclomaticComplexity.xml -f xml -o CheckStyle/reader-core_CyclomaticComplexity.xml ../reader-core
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_JavaNCSS.xml -f xml -o CheckStyle/reader-core_JavaNCSS.xml ../reader-core
java -jar utils/checkstyle-9.3-all.jar -c utils/checkstyle_NPathComplexity.xml -f xml -o CheckStyle/reader-core_NPathComplexity.xml ../reader-core



pmd check -R utils/pmd_CognitiveComplexity.xml -d ../reader-web -f text --report-file PMD/reader-web_CognitiveComplexity.txt
pmd check -R utils/pmd_CouplingBetweenObjects.xml -d ../reader-web -f text --report-file PMD/reader-web_CouplingBetweenObjects.txt
pmd check -R utils/pmd_CyclomaticComplexity.xml -d ../reader-web -f text --report-file PMD/reader-web_CyclomaticComplexity.txt
pmd check -R utils/pmd_DataClass.xml -d ../reader-web -f text --report-file PMD/reader-web_DataClass.txt
pmd check -R utils/pmd_ExcessiveImports.xml -d ../reader-web -f text --report-file PMD/reader-web_ExcessiveImports.txt
pmd check -R utils/pmd_ExcessiveParameterList.xml -d ../reader-web -f text --report-file PMD/reader-web_ExcessiveParameterList.txt
pmd check -R utils/pmd_ExcessivePublicCount.xml -d ../reader-web -f text --report-file PMD/reader-web_ExcessivePublicCount.txt
pmd check -R utils/pmd_LoosePackageCoupling.xml -d ../reader-web -f text --report-file PMD/reader-web_LoosePackageCoupling.txt
pmd check -R utils/pmd_NcssCount.xml -d ../reader-web -f text --report-file PMD/reader-web_NcssCount.txt
pmd check -R utils/pmd_NPathComplexity.xml -d ../reader-web -f text --report-file PMD/reader-web_NPathComplexity.txt
pmd check -R utils/pmd_SwitchDensity.xml -d ../reader-web -f text --report-file PMD/reader-web_SwitchDensity.txt
pmd check -R utils/pmd_TooManyFields.xml -d ../reader-web -f text --report-file PMD/reader-web_TooManyFields.txt
pmd check -R utils/pmd_TooManyMethods.xml -d ../reader-web -f text --report-file PMD/reader-web_TooManyMethods.txt

pmd check -R utils/pmd_CognitiveComplexity.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_CognitiveComplexity.txt
pmd check -R utils/pmd_CouplingBetweenObjects.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_CouplingBetweenObjects.txt
pmd check -R utils/pmd_CyclomaticComplexity.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_CyclomaticComplexity.txt
pmd check -R utils/pmd_DataClass.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_DataClass.txt
pmd check -R utils/pmd_ExcessiveImports.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_ExcessiveImports.txt
pmd check -R utils/pmd_ExcessiveParameterList.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_ExcessiveParameterList.txt
pmd check -R utils/pmd_ExcessivePublicCount.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_ExcessivePublicCount.txt
pmd check -R utils/pmd_LoosePackageCoupling.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_LoosePackageCoupling.txt
pmd check -R utils/pmd_NcssCount.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_NcssCount.txt
pmd check -R utils/pmd_NPathComplexity.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_NPathComplexity.txt
pmd check -R utils/pmd_SwitchDensity.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_SwitchDensity.txt
pmd check -R utils/pmd_TooManyFields.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_TooManyFields.txt
pmd check -R utils/pmd_TooManyMethods.xml -d ../reader-web-common -f text --report-file PMD/reader-web-common_TooManyMethods.txt

pmd check -R utils/pmd_CognitiveComplexity.xml -d ../reader-core -f text --report-file PMD/reader-core_CognitiveComplexity.txt
pmd check -R utils/pmd_CouplingBetweenObjects.xml -d ../reader-core -f text --report-file PMD/reader-core_CouplingBetweenObjects.txt
pmd check -R utils/pmd_CyclomaticComplexity.xml -d ../reader-core -f text --report-file PMD/reader-core_CyclomaticComplexity.txt
pmd check -R utils/pmd_DataClass.xml -d ../reader-core -f text --report-file PMD/reader-core_DataClass.txt
pmd check -R utils/pmd_ExcessiveImports.xml -d ../reader-core -f text --report-file PMD/reader-core_ExcessiveImports.txt
pmd check -R utils/pmd_ExcessiveParameterList.xml -d ../reader-core -f text --report-file PMD/reader-core_ExcessiveParameterList.txt
pmd check -R utils/pmd_ExcessivePublicCount.xml -d ../reader-core -f text --report-file PMD/reader-core_ExcessivePublicCount.txt
pmd check -R utils/pmd_LoosePackageCoupling.xml -d ../reader-core -f text --report-file PMD/reader-core_LoosePackageCoupling.txt
pmd check -R utils/pmd_NcssCount.xml -d ../reader-core -f text --report-file PMD/reader-core_NcssCount.txt
pmd check -R utils/pmd_NPathComplexity.xml -d ../reader-core -f text --report-file PMD/reader-core_NPathComplexity.txt
pmd check -R utils/pmd_SwitchDensity.xml -d ../reader-core -f text --report-file PMD/reader-core_SwitchDensity.txt
pmd check -R utils/pmd_TooManyFields.xml -d ../reader-core -f text --report-file PMD/reader-core_TooManyFields.txt
pmd check -R utils/pmd_TooManyMethods.xml -d ../reader-core -f text --report-file PMD/reader-core_TooManyMethods.txt