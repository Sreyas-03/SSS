# Using PMD
# 🔹 Reader Core 🔹

## Cognitivecomplexity
```
reader-core/src/main/java/com/sismics/reader/core/dao/file/html/FaviconDownloader.java:127:	CognitiveComplexity:	The method 'downloadFavicon(String, String, String)' has a cognitive complexity of 22, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/dao/file/html/FaviconExtractor.java:57:	CognitiveComplexity:	The method 'startElement(String, String, String, Attributes)' has a cognitive complexity of 16, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/dao/file/json/StarredReader.java:32:	CognitiveComplexity:	The method 'read(InputStream)' has a cognitive complexity of 25, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/dao/file/opml/OpmlReader.java:81:	CognitiveComplexity:	The method 'startElement(String, String, String, Attributes)' has a cognitive complexity of 15, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/RssReader.java:239:	CognitiveComplexity:	The method 'startElement(String, String, String, Attributes)' has a cognitive complexity of 84, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/XmlReader.java:52:	CognitiveComplexity:	The constructor 'XmlReader(InputStream, String)' has a cognitive complexity of 26, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/UserArticleDao.java:26:	CognitiveComplexity:	The method 'getQueryParam(UserArticleCriteria, FilterCriteria)' has a cognitive complexity of 24, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:97:	CognitiveComplexity:	The method 'createJob(User, File)' has a cognitive complexity of 17, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:203:	CognitiveComplexity:	The method 'processImportFile(User, File, Job)' has a cognitive complexity of 38, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:304:	CognitiveComplexity:	The method 'importOutline(User, List<Outline>, Job)' has a cognitive complexity of 36, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:432:	CognitiveComplexity:	The method 'importFeedFromStarred(User, Feed, Article)' has a cognitive complexity of 17, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/service/FeedService.java:139:	CognitiveComplexity:	The method 'synchronize(String)' has a cognitive complexity of 40, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/util/DirectoryUtil.java:19:	CognitiveComplexity:	The method 'getBaseDataDirectory()' has a cognitive complexity of 15, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/util/TransactionUtil.java:28:	CognitiveComplexity:	The method 'handle(Runnable)' has a cognitive complexity of 19, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/util/sanitizer/ArticleSanitizer.java:50:	CognitiveComplexity:	The method 'sanitize(String, String)' has a cognitive complexity of 28, current threshold is 15
reader-core/src/main/java/com/sismics/reader/core/util/sanitizer/ArticleSanitizer.java:80:	CognitiveComplexity:	The method 'apply(String, String, String)' has a cognitive complexity of 16, current threshold is 15
reader-core/src/main/java/com/sismics/util/AdblockUtil.java:128:	CognitiveComplexity:	The method 'offerSubscription()' has a cognitive complexity of 15, current threshold is 15
reader-core/src/main/java/com/sismics/util/ResourceUtil.java:32:	CognitiveComplexity:	The method 'list(Class<?>, String, FilenameFilter)' has a cognitive complexity of 25, current threshold is 15
reader-core/src/main/java/com/sismics/util/jpa/DbOpenHelper.java:169:	CognitiveComplexity:	The method 'executeScript(InputStream)' has a cognitive complexity of 16, current threshold is 15
reader-core/src/main/java/com/sismics/util/jpa/ResultMapper.java:63:	CognitiveComplexity:	The method 'booleanValue(Object)' has a cognitive complexity of 15, current threshold is 15
reader-core/src/main/java/com/sismics/util/jpa/ResultMapper.java:80:	CognitiveComplexity:	The method 'longValue(Object)' has a cognitive complexity of 15, current threshold is 15
```

## Cyclomaticcomplexity
```
reader-core/src/main/java/com/sismics/reader/core/dao/file/json/StarredReader.java:32:	CyclomaticComplexity:	The method 'read(InputStream)' has a cyclomatic complexity of 12.
reader-core/src/main/java/com/sismics/reader/core/dao/file/opml/OpmlReader.java:81:	CyclomaticComplexity:	The method 'startElement(String, String, String, Attributes)' has a cyclomatic complexity of 14.
reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/RssReader.java:25:	CyclomaticComplexity:	The class 'RssReader' has a total cyclomatic complexity of 175 (highest 124).
reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/RssReader.java:239:	CyclomaticComplexity:	The method 'startElement(String, String, String, Attributes)' has a cyclomatic complexity of 124.
reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/XmlReader.java:52:	CyclomaticComplexity:	The constructor 'XmlReader(InputStream, String)' has a cyclomatic complexity of 20.
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/UserArticleDao.java:23:	CyclomaticComplexity:	The class 'UserArticleDao' has a total cyclomatic complexity of 32 (highest 20).
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/UserArticleDao.java:26:	CyclomaticComplexity:	The method 'getQueryParam(UserArticleCriteria, FilterCriteria)' has a cyclomatic complexity of 20.
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/criteria/UserArticleCriteria.java:11:	CyclomaticComplexity:	The class 'UserArticleCriteria' has a total cyclomatic complexity of 32 (highest 1).
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/FeedSubscriptionDto.java:10:	CyclomaticComplexity:	The class 'FeedSubscriptionDto' has a total cyclomatic complexity of 30 (highest 1).
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/UserArticleDto.java:11:	CyclomaticComplexity:	The class 'UserArticleDto' has a total cyclomatic complexity of 39 (highest 3).
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:51:	CyclomaticComplexity:	The class 'SubscriptionImportAsyncListener' has a total cyclomatic complexity of 55 (highest 16).
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:203:	CyclomaticComplexity:	The method 'processImportFile(User, File, Job)' has a cyclomatic complexity of 13.
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:304:	CyclomaticComplexity:	The method 'importOutline(User, List<Outline>, Job)' has a cyclomatic complexity of 16.
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:432:	CyclomaticComplexity:	The method 'importFeedFromStarred(User, Feed, Article)' has a cyclomatic complexity of 13.
reader-core/src/main/java/com/sismics/reader/core/model/jpa/Article.java:15:	CyclomaticComplexity:	The class 'Article' has a total cyclomatic complexity of 35 (highest 1).
reader-core/src/main/java/com/sismics/reader/core/model/jpa/User.java:19:	CyclomaticComplexity:	The class 'User' has a total cyclomatic complexity of 31 (highest 1).
reader-core/src/main/java/com/sismics/reader/core/service/FeedService.java:56:	CyclomaticComplexity:	The class 'FeedService' has a total cyclomatic complexity of 48 (highest 23).
reader-core/src/main/java/com/sismics/reader/core/service/FeedService.java:139:	CyclomaticComplexity:	The method 'synchronize(String)' has a cyclomatic complexity of 23.
reader-core/src/main/java/com/sismics/reader/core/util/TransactionUtil.java:28:	CyclomaticComplexity:	The method 'handle(Runnable)' has a cyclomatic complexity of 12.
reader-core/src/main/java/com/sismics/reader/core/util/jpa/PaginatedLists.java:19:	CyclomaticComplexity:	The class 'PaginatedLists' has a total cyclomatic complexity of 32 (highest 7).
reader-core/src/main/java/com/sismics/reader/core/util/sanitizer/ArticleSanitizer.java:80:	CyclomaticComplexity:	The method 'apply(String, String, String)' has a cyclomatic complexity of 12.
reader-core/src/main/java/com/sismics/util/AdblockUtil.java:40:	CyclomaticComplexity:	The class 'AdblockUtil' has a total cyclomatic complexity of 31 (highest 9).
reader-core/src/main/java/com/sismics/util/JsonValidationUtil.java:12:	CyclomaticComplexity:	The class 'JsonValidationUtil' has a total cyclomatic complexity of 38 (highest 7).
reader-core/src/main/java/com/sismics/util/ResourceUtil.java:32:	CyclomaticComplexity:	The method 'list(Class<?>, String, FilenameFilter)' has a cyclomatic complexity of 14.
reader-core/src/main/java/com/sismics/util/jpa/DbOpenHelper.java:37:	CyclomaticComplexity:	The class 'DbOpenHelper' has a total cyclomatic complexity of 35 (highest 11).
reader-core/src/main/java/com/sismics/util/jpa/DbOpenHelper.java:63:	CyclomaticComplexity:	The method 'open()' has a cyclomatic complexity of 11.
reader-core/src/main/java/com/sismics/util/jpa/ResultMapper.java:21:	CyclomaticComplexity:	The class 'ResultMapper' has a total cyclomatic complexity of 46 (highest 6).
reader-core/src/main/java/com/sismics/util/log4j/MemoryAppender.java:101:	CyclomaticComplexity:	The method 'find(LogCriteria, PaginatedList<LogEntry>)' has a cyclomatic complexity of 10.
reader-core/src/main/java/com/sismics/util/mime/MimeType.java:23:	CyclomaticComplexity:	The method 'guessMimeType(File)' has a cyclomatic complexity of 21.
reader-core/src/test/java/com/sismics/reader/core/dao/file/rss/TestRssReader.java:18:	CyclomaticComplexity:	The class 'TestRssReader' has a total cyclomatic complexity of 32 (highest 2).
```

## Dataclass
```
reader-core/src/main/java/com/sismics/reader/core/constant/Constants.java:8:	DataClass:	The class 'Constants' is suspected to be a Data Class (WOC=0.000%, NOPA=14, NOAM=0, WMC=0)
reader-core/src/main/java/com/sismics/reader/core/dao/file/json/StarredArticleImportedEvent.java:12:	DataClass:	The class 'StarredArticleImportedEvent' is suspected to be a Data Class (WOC=20.000%, NOPA=0, NOAM=4, WMC=5)
reader-core/src/main/java/com/sismics/reader/core/dao/file/opml/Outline.java:11:	DataClass:	The class 'Outline' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=11, WMC=12)
reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/AtomLink.java:8:	DataClass:	The class 'AtomLink' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=6, WMC=7)
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/ArticleDto.java:10:	DataClass:	The class 'ArticleDto' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=28, WMC=28)
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/FeedDto.java:8:	DataClass:	The class 'FeedDto' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=4, WMC=4)
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/FeedSubscriptionDto.java:10:	DataClass:	The class 'FeedSubscriptionDto' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=30, WMC=30)
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/JobDto.java:8:	DataClass:	The class 'JobDto' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=12, WMC=12)
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/JobEventDto.java:8:	DataClass:	The class 'JobEventDto' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=6, WMC=6)
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/UserArticleDto.java:11:	DataClass:	The class 'UserArticleDto' is suspected to be a Data Class (WOC=2.703%, NOPA=0, NOAM=36, WMC=39)
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/dto/UserDto.java:8:	DataClass:	The class 'UserDto' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=10, WMC=10)
reader-core/src/main/java/com/sismics/reader/core/event/SubscriptionImportedEvent.java:13:	DataClass:	The class 'SubscriptionImportedEvent' is suspected to be a Data Class (WOC=20.000%, NOPA=0, NOAM=4, WMC=5)
reader-core/src/main/java/com/sismics/reader/core/model/context/AppContext.java:28:	DataClass:	The class 'AppContext' is suspected to be a Data Class (WOC=10.000%, NOPA=0, NOAM=9, WMC=21)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/Article.java:15:	DataClass:	The class 'Article' is suspected to be a Data Class (WOC=3.030%, NOPA=0, NOAM=32, WMC=35)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/AuthenticationToken.java:19:	DataClass:	The class 'AuthenticationToken' is suspected to be a Data Class (WOC=9.091%, NOPA=0, NOAM=10, WMC=11)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/Category.java:19:	DataClass:	The class 'Category' is suspected to be a Data Class (WOC=5.882%, NOPA=0, NOAM=16, WMC=17)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/Config.java:20:	DataClass:	The class 'Config' is suspected to be a Data Class (WOC=20.000%, NOPA=0, NOAM=4, WMC=5)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/Feed.java:18:	DataClass:	The class 'Feed' is suspected to be a Data Class (WOC=4.762%, NOPA=0, NOAM=20, WMC=23)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/FeedSubscription.java:18:	DataClass:	The class 'FeedSubscription' is suspected to be a Data Class (WOC=5.263%, NOPA=0, NOAM=18, WMC=19)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/FeedSynchronization.java:20:	DataClass:	The class 'FeedSynchronization' is suspected to be a Data Class (WOC=7.692%, NOPA=0, NOAM=12, WMC=13)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/Job.java:19:	DataClass:	The class 'Job' is suspected to be a Data Class (WOC=6.667%, NOPA=0, NOAM=14, WMC=17)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/JobEvent.java:19:	DataClass:	The class 'JobEvent' is suspected to be a Data Class (WOC=7.692%, NOPA=0, NOAM=12, WMC=15)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/Role.java:19:	DataClass:	The class 'Role' is suspected to be a Data Class (WOC=11.111%, NOPA=0, NOAM=8, WMC=9)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/RoleBaseFunction.java:19:	DataClass:	The class 'RoleBaseFunction' is suspected to be a Data Class (WOC=9.091%, NOPA=0, NOAM=10, WMC=11)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/User.java:19:	DataClass:	The class 'User' is suspected to be a Data Class (WOC=3.226%, NOPA=0, NOAM=30, WMC=31)
reader-core/src/main/java/com/sismics/reader/core/model/jpa/UserArticle.java:19:	DataClass:	The class 'UserArticle' is suspected to be a Data Class (WOC=6.667%, NOPA=0, NOAM=14, WMC=15)
reader-core/src/main/java/com/sismics/reader/core/util/jpa/PaginatedList.java:10:	DataClass:	The class 'PaginatedList' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=6, WMC=7)
reader-core/src/main/java/com/sismics/util/adblock/Subscription.java:20:	DataClass:	The class 'Subscription' is suspected to be a Data Class (WOC=0.000%, NOPA=6, NOAM=0, WMC=0)
reader-core/src/main/java/com/sismics/util/jpa/QueryParam.java:14:	DataClass:	The class 'QueryParam' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=9, WMC=11)
reader-core/src/main/java/com/sismics/util/log4j/LogEntry.java:8:	DataClass:	The class 'LogEntry' is suspected to be a Data Class (WOC=0.000%, NOPA=0, NOAM=4, WMC=5)
```

## Npathcomplexity
```
reader-core/src/main/java/com/sismics/reader/core/dao/file/json/StarredReader.java:32:	NPathComplexity:	The method 'read(InputStream)' has an NPath complexity of 325, current threshold is 200
reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/RssReader.java:239:	NPathComplexity:	The method 'startElement(String, String, String, Attributes)' has an NPath complexity of 244, current threshold is 200
reader-core/src/main/java/com/sismics/reader/core/dao/jpa/UserArticleDao.java:26:	NPathComplexity:	The method 'getQueryParam(UserArticleCriteria, FilterCriteria)' has an NPath complexity of 92160, current threshold is 200
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:304:	NPathComplexity:	The method 'importOutline(User, List<Outline>, Job)' has an NPath complexity of 1752, current threshold is 200
reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java:432:	NPathComplexity:	The method 'importFeedFromStarred(User, Feed, Article)' has an NPath complexity of 320, current threshold is 200
reader-core/src/main/java/com/sismics/reader/core/service/FeedService.java:139:	NPathComplexity:	The method 'synchronize(String)' has an NPath complexity of 23328, current threshold is 200
reader-core/src/main/java/com/sismics/reader/core/util/sanitizer/ArticleSanitizer.java:50:	NPathComplexity:	The method 'sanitize(String, String)' has an NPath complexity of 396, current threshold is 200
reader-core/src/main/java/com/sismics/util/ResourceUtil.java:32:	NPathComplexity:	The method 'list(Class<?>, String, FilenameFilter)' has an NPath complexity of 390, current threshold is 200
```

## Ncsscount
No content in file.


---
# 🔹 Reader Web 🔹

## Cognitivecomplexity
```
reader-web/src/main/java/com/sismics/reader/rest/dao/ThemeDao.java:33:	CognitiveComplexity:	The method 'findAll(ServletContext)' has a cognitive complexity of 23, current threshold is 15
reader-web/src/main/java/com/sismics/reader/rest/resource/SubscriptionResource.java:124:	CognitiveComplexity:	The method 'list(boolean)' has a cognitive complexity of 20, current threshold is 15
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:569:	CognitiveComplexity:	The method 'info()' has a cognitive complexity of 20, current threshold is 15
```

## Cyclomaticcomplexity
```
reader-web/src/main/java/com/sismics/reader/rest/resource/AppResource.java:41:	CyclomaticComplexity:	The class 'AppResource' has a total cyclomatic complexity of 30 (highest 9).
reader-web/src/main/java/com/sismics/reader/rest/resource/ArticleResource.java:39:	CyclomaticComplexity:	The class 'ArticleResource' has a total cyclomatic complexity of 36 (highest 8).
reader-web/src/main/java/com/sismics/reader/rest/resource/CategoryResource.java:46:	CyclomaticComplexity:	The class 'CategoryResource' has a total cyclomatic complexity of 43 (highest 10).
reader-web/src/main/java/com/sismics/reader/rest/resource/CategoryResource.java:145:	CyclomaticComplexity:	The method 'get(String, boolean, Integer, String)' has a cyclomatic complexity of 10.
reader-web/src/main/java/com/sismics/reader/rest/resource/StarredResource.java:39:	CyclomaticComplexity:	The class 'StarredResource' has a total cyclomatic complexity of 39 (highest 7).
reader-web/src/main/java/com/sismics/reader/rest/resource/SubscriptionResource.java:69:	CyclomaticComplexity:	The class 'SubscriptionResource' has a total cyclomatic complexity of 86 (highest 13).
reader-web/src/main/java/com/sismics/reader/rest/resource/SubscriptionResource.java:124:	CyclomaticComplexity:	The method 'list(boolean)' has a cyclomatic complexity of 13.
reader-web/src/main/java/com/sismics/reader/rest/resource/SubscriptionResource.java:432:	CyclomaticComplexity:	The method 'update(String, String, String, Integer)' has a cyclomatic complexity of 10.
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:56:	CyclomaticComplexity:	The class 'UserResource' has a total cyclomatic complexity of 106 (highest 18).
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:114:	CyclomaticComplexity:	The method 'register(String, String, String, String)' has a cyclomatic complexity of 10.
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:202:	CyclomaticComplexity:	The method 'update(String, String, String, String, Boolean, Boolean, Boolean, Boolean, Boolean, Boolean)' has a cyclomatic complexity of 16.
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:292:	CyclomaticComplexity:	The method 'update(String, String, String, String, String, Boolean, Boolean, Boolean, Boolean, Boolean)' has a cyclomatic complexity of 18.
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:455:	CyclomaticComplexity:	The method 'logout()' has a cyclomatic complexity of 11.
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:569:	CyclomaticComplexity:	The method 'info()' has a cyclomatic complexity of 12.
```

## Npathcomplexity
```
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:202:	NPathComplexity:	The method 'update(String, String, String, String, Boolean, Boolean, Boolean, Boolean, Boolean, Boolean)' has an NPath complexity of 12288, current threshold is 200
reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java:292:	NPathComplexity:	The method 'update(String, String, String, String, String, Boolean, Boolean, Boolean, Boolean, Boolean)' has an NPath complexity of 6144, current threshold is 200
```

---
# 🔹 Reader Web Common 🔹

## Cognitivecomplexity
```
reader-web-common/src/main/java/com/sismics/util/filter/RequestContextFilter.java:91:	CognitiveComplexity:	The method 'doFilter(ServletRequest, ServletResponse, FilterChain)' has a cognitive complexity of 27, current threshold is 15
```

## Cyclomaticcomplexity
```
reader-web-common/src/main/java/com/sismics/rest/util/ValidationUtil.java:18:	CyclomaticComplexity:	The class 'ValidationUtil' has a total cyclomatic complexity of 31 (highest 11).
reader-web-common/src/main/java/com/sismics/rest/util/ValidationUtil.java:47:	CyclomaticComplexity:	The method 'validateLength(String, String, Integer, Integer, boolean)' has a cyclomatic complexity of 11.
reader-web-common/src/main/java/com/sismics/util/filter/RequestContextFilter.java:91:	CyclomaticComplexity:	The method 'doFilter(ServletRequest, ServletResponse, FilterChain)' has a cyclomatic complexity of 16.
reader-web-common/src/test/java/com/sismics/reader/rest/BaseJerseyTest.java:46:	CyclomaticComplexity:	The class 'BaseJerseyTest' has a total cyclomatic complexity of 46 (highest 3).
```

## Dataclass
```
reader-web-common/src/main/java/com/sismics/security/UserPrincipal.java:13:	DataClass:	The class 'UserPrincipal' is suspected to be a Data Class (WOC=7.692%, NOPA=0, NOAM=12, WMC=14)
```



---
---
# Using Checkstyle
# 🔹 Reader Core 🔹
## ClassFanOutComplexity
```
<file name="reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/RssReader.java">
<error line="25" column="1" severity="error" message="Class Fan-Out Complexity is 31 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/service/FeedService.java">
<error line="56" column="1" severity="error" message="Class Fan-Out Complexity is 36 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java">
<error line="51" column="1" severity="error" message="Class Fan-Out Complexity is 38 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>
```

## ClassDataAbstractionCoupling
```
<file name="reader-core/src/main/java/com/sismics/reader/core/model/context/AppContext.java">
<error line="28" column="1" severity="error" message="Class Data Abstraction Coupling is 16 (max allowed is 7) classes [ArticleCreatedAsyncListener, ArticleDeletedAsyncListener, ArticleIndexingService, ArticleUpdatedAsyncListener, AsyncEventBus, ConfigDao, DeadEventListener, DirectoryIndexingService, EventBus, FaviconUpdateRequestedAsyncListener, FeedService, IndexingService, LinkedBlockingQueue, RebuildIndexAsyncListener, SubscriptionImportAsyncListener, ThreadPoolExecutor]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/dao/file/rss/RssReader.java">
<error line="25" column="1" severity="error" message="Class Data Abstraction Coupling is 12 (max allowed is 7) classes [Article, AtomArticleCommentUrlGuesserStrategy, AtomArticleUrlGuesserStrategy, AtomLink, AtomUrlGuesserStrategy, DateTimeFormatterBuilder, DateTimeParser, Feed, SAXException, Stack, XmlReader, org.xml.sax.InputSource]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/dao/lucene/ArticleDao.java">
<error line="37" column="1" severity="error" message="Class Data Abstraction Coupling is 19 (max allowed is 7) classes [Article, BooleanQuery, Field, FieldType, GroupingSearch, IndexSearcher, LongField, PassageFormatter, PassageScorer, PostingsHighlighter, ReaderStandardAnalyzer, ScoreDoc, Sort, SortField, StandardQueryParser, StringField, Term, TopDocs, org.apache.lucene.document.Document]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/service/FeedService.java">
<error line="56" column="1" severity="error" message="Class Data Abstraction Coupling is 26 (max allowed is 7) classes [Article, ArticleCreatedAsyncEvent, ArticleCriteria, ArticleDao, ArticleDeletedAsyncEvent, ArticleFeedService, ArticleSanitizer, ArticleUpdatedAsyncEvent, Date, FaviconFeedService, FaviconUpdateRequestedEvent, Feed, FeedChooserStrategy, FeedCriteria, FeedDao, FeedSubscriptionCriteria, FeedSubscriptionDao, FeedSynchronization, FeedSynchronizationDao, ReaderHttpClient, RssExtractor, RssReader, URL, UserArticle, UserArticleCriteria, UserArticleDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/service/ArticleFeedService.java">
<error line="28" column="1" severity="error" message="Class Data Abstraction Coupling is 10 (max allowed is 7) classes [Article, ArticleCriteria, ArticleDao, Date, DateTime, FeedService, FeedSubscriptionDao, UserArticle, UserArticleCriteria, UserArticleDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/service/ArticleIndexingService.java">
<error line="34" column="1" severity="error" message="Class Data Abstraction Coupling is 9 (max allowed is 7) classes [ArticleDao, Date, RAMDirectory, RebuildIndexAsyncEvent, SimpleFSDirectory, SimpleFSLockFactory, UserArticle, UserArticleCriteria, UserArticleDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-core/src/main/java/com/sismics/reader/core/listener/async/SubscriptionImportAsyncListener.java">
<error line="51" column="1" severity="error" message="Class Data Abstraction Coupling is 25 (max allowed is 7) classes [ArticleCreatedAsyncEvent, ArticleCriteria, ArticleDao, ArticleFeedService, AtomicInteger, Category, CategoryDao, Date, Feed, FeedDao, FeedSubscription, FeedSubscriptionCriteria, FeedSubscriptionDao, FileInputStream, FileOutputStream, Job, JobDao, JobEvent, JobEventDao, OpmlReader, StarredReader, UserArticle, UserArticleCriteria, UserArticleDao, ZipArchiveInputStream]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
```

---
# 🔹 Reader Web 🔹
## ClassFanOutComplexity
```
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java">
<error line="55" column="1" severity="error" message="Class Fan-Out Complexity is 44 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/ArticleResource.java">
<error line="38" column="1" severity="error" message="Class Fan-Out Complexity is 26 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/SubscriptionResource.java">
<error line="68" column="1" severity="error" message="Class Fan-Out Complexity is 59 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/CategoryResource.java">
<error line="45" column="1" severity="error" message="Class Fan-Out Complexity is 32 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/StarredResource.java">
<error line="38" column="1" severity="error" message="Class Fan-Out Complexity is 26 (max allowed is 25)." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassFanOutComplexityCheck"/>
</file>

```

## ClassDataAbstractionCoupling
```
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/UserResource.java">
<error line="55" column="1" severity="error" message="Class Data Abstraction Coupling is 22 (max allowed is 7) classes [AuthenticationToken, AuthenticationTokenDao, Category, CategoryDao, ClientException, Date, ForbiddenClientException, JSONArray, JSONObject, JobCriteria, JobDao, JobEventCriteria, JobEventDao, NewCookie, PasswordChangedEvent, RoleBaseFunctionDao, ServerException, SortCriteria, User, UserCreatedEvent, UserCriteria, UserDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/ArticleResource.java">
<error line="38" column="1" severity="error" message="Class Data Abstraction Coupling is 9 (max allowed is 7) classes [ArticleCriteria, ArticleDao, ClientException, Date, FeedSubscriptionCriteria, FeedSubscriptionDao, ForbiddenClientException, JSONObject, UserArticleDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<error line="68" column="1" severity="error" message="Class Data Abstraction Coupling is 21 (max allowed is 7) classes [ArticleFeedService, CategoryDao, ClientException, DOMSource, Date, FeedSubscription, FeedSubscriptionCriteria, FeedSubscriptionDao, FeedSynchronizationDao, File, FileInputStream, FileOutputStream, ForbiddenClientException, JSONArray, JSONObject, ServerException, SimpleDateFormat, SubscriptionImportedEvent, UserArticleCriteria, UserArticleDao, UserDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/CategoryResource.java">
<error line="45" column="1" severity="error" message="Class Data Abstraction Coupling is 10 (max allowed is 7) classes [Category, CategoryDao, ClientException, Date, FeedSubscriptionCriteria, FeedSubscriptionDao, ForbiddenClientException, JSONObject, UserArticleCriteria, UserArticleDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
<file name="reader-web/src/main/java/com/sismics/reader/rest/resource/AllResource.java">
<error line="40" column="1" severity="error" message="Class Data Abstraction Coupling is 8 (max allowed is 7) classes [ClientException, Date, FeedSubscriptionCriteria, FeedSubscriptionDao, ForbiddenClientException, JSONObject, UserArticleCriteria, UserArticleDao]." source="com.puppycrawl.tools.checkstyle.checks.metrics.ClassDataAbstractionCouplingCheck"/>
</file>
```
