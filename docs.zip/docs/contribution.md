## 📌 Contribution Table

| 👤 Contributor | 🛠️ Task |
|--------------|---------------------------------------------|
| **Sreyas**   | UML (Subtask 1), Design Smell Detection, Code Refactoring |
| **Sankalp**  | UML (Subtask 2), Design Smell Detection, Code Refactoring |
| **Sreenivas**| Design Smell Detection, Code Refactoring, LLM Refactoring |
| **Krishna**  | UML (Subtask 3), Design Smell Detection, Code Refactoring |
| **Yash**     | Design Smell Detection, Code Metrics, Automated Refactoring |

✨ **The contribution of each team member was equal in terms of time and effort.**
